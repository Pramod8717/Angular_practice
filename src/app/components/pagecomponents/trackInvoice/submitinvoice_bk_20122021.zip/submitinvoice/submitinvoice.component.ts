import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { DialogModelComponent } from 'app/components/dialogcomponent/dialog-model/dialog-model.component';
import { LoaderService } from 'app/services/LoaderService/loader.service';
// import { DialogModelComponent } from 'app/dialog-model/dialog-model.component';
import { PurchaseOrderListService } from 'app/services/purchaseOrderList/purchaseorderlist.service';
// import moment = require('moment');
import * as moment from 'moment/moment';
import { ToastrService } from 'ngx-toastr';


declare var $: any;

@Component({
  selector: 'app-submitinvoice',
  templateUrl: './submitinvoice.component.html',
  styleUrls: ['./submitinvoice.component.css']
})
export class SubmitInvoiceComponent implements OnInit {
  IGST: boolean = true;
  invoice: boolean = true;
  irndetail: boolean = false;
  bignumber: boolean = false;
  bignumbercgst: boolean = false;
  bignumbersgst: boolean = false;
  isReadOnly: boolean = false;
  specificcgst: boolean = false;
  specificsgst: boolean = false;
  disable: boolean = false;
  successmessage: string;
  podetail = [];
  igstlist = [];
  cgstandsgstlist = [];
  // invoiceDate : any;
  ponumber: string;
  bussinesspartnertext: string;
  category: string;
  costcenter: string;
  lineitemnumber: string;
  lineitemtext: string;
  quantity: string;
  unitofmeasure: string;
  contactpersonemailid: string;
  contactpersonphone: string;
  company: string;
  plant: string;
  department: string;
  data: string;
  vendor: string;
  contactemail: string;
  ordernumber: string;
  //file upload
  viewUploadFile: any = null;
  invoiceconfile: string;
  viewAttachmentName: string = "";
  submitbutton: string = "";
  AttachmentValidExtension: string[] = ["CSV"];
  isUpload: boolean;

  fileAttachmentError: string = "";
  success: boolean = false;
  error: boolean = false;
  maxdate: Date;
  confirmationNoAction: boolean = false;
  //fileAttachmentError = [];
  InvalidAttachmentFileError =
    "Selected file is having Invalid extension. Valid file extensions are pdf, jpg & jpeg.";


  public InvoiceForm = new FormGroup({
    // IRNNo: new FormControl(''),
    // IRNDate: new FormControl(''),
    Useremail: new FormControl(''),
    Invnumber: new FormControl('', Validators.required),
    InvDate: new FormControl('', Validators.required),
    Invamount: new FormControl('', Validators.required),
    // IGSTValue: new FormControl('', ),
    // CGSTValue: new FormControl('', ),
    // SGSTValue: new FormControl('', ),
    // TotalValue: new FormControl('', Validators.required),
    Description: new FormControl('', Validators.required),
    attachments: new FormControl('', Validators.required),

    // PONumber: new FormControl('', Validators.required),
    // Status: new FormControl('', Validators.required),
    // selectPO: new FormControl('', Validators.required),
    // lastYear: new FormControl('', Validators.required),
    // from: new FormControl('', Validators.required),
    // to: new FormControl('', Validators.required),
    // invDate: new FormControl('', Validators.required),
    // PODate: new FormControl('', Validators.required),
    // POValue: new FormControl('', Validators.required)
  })

  public hasError = (controlName: string, errorName: string) => {
    return this.InvoiceForm.controls[controlName].hasError(errorName);
  }
  WithoutPO: boolean = false;
  actualfilename: any;
  savedfilename: string;
  value: string;
  RevisedbalQuantity: number;
  errorlist: any = [];
  errorcount: any;
  insertcount: any;
  flag: any;




  constructor(private purchaseOrderListService: PurchaseOrderListService, private route: ActivatedRoute, private router: Router, private toastr: ToastrService,
    private loaderservice: LoaderService) { }
  @ViewChild(DialogModelComponent) dialogBox: DialogModelComponent;

  ngOnInit(): void {
    this.gstvalue();
    $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })
    this.maxdate = new Date();
  }


  changeEvent(event) {
    let value = event.target.value

    if (value == "WithoutPO") {
      this.WithoutPO = true;
      this.InvoiceForm.get('Useremail').setValidators(Validators.required);
    }
    else {
      this.WithoutPO = false
      this.InvoiceForm.get('Useremail').setValidators(null);
    }
  }

  checkIGST(event) {
    let value = event.target.value
    this.InvoiceForm.controls['TotalValue'].setValue(this.InvoiceForm.controls['Invamount'].value);
    if (value == "IGST") {
      this.IGST = true;
    }
    else {
      this.IGST = false;
    }
  }


  checkInvoice(event) {
    let value = event.target.value
    if (value == "Invoice") {

      this.irndetail = false;
      this.invoice = true;
      this.InvoiceForm.controls['IRNNo'].clearValidators();
      this.InvoiceForm.controls['IRNDate'].clearValidators();
    }
    else {
      // this.InvoiceForm.get['IRNNo'].setValidators()

      this.irndetail = true;
      this.invoice = false;
      this.InvoiceForm.controls['IRNNo'].setValidators([Validators.required]);
      this.InvoiceForm.controls['IRNDate'].setValidators([Validators.required]);
    }
  }

  submitinvoicedetail() {
    console.log("is valid??", this.InvoiceForm);


    this.loaderservice.show();
    // var ponumber = this.ponumber;
    var irnnumber = "";
    var irndate = "";
    // if (this.invoice != true) {
    //   irnnumber = this.InvoiceForm.controls['IRNNo'].value;
    //   irndate = moment(new Date(this.InvoiceForm.controls['IRNDate'].value)).format("DD/MM/YYYY");

    // }
    var useremail = this.InvoiceForm.controls['Useremail'].value;
    var invoiceNumber = this.InvoiceForm.controls['Invnumber'].value;

    // var invoicedate = this.InvoiceForm.controls['InvDate'].value;
    var invoicedate = moment(new Date(this.InvoiceForm.controls['InvDate'].value)).format("DD/MM/YYYY")
    // var refno = "ref1234";
    // var grnnumber = "";
    // if (this.data == "poitem") {
    //   var lineitemnumber = "-";
    //   var ordernumber = "-";
    // }
    // else if (this.data == "lineitem") {
    //   var lineitemnumber = this.lineitemnumber;
    //   var ordernumber = "-";
    // }
    // else if (this.data == "orderitem") {
    //   var lineitemnumber = this.lineitemnumber;
    //   var ordernumber = this.ordernumber;
    // }
    // var lineitemnumber = "";
    //     var ordernumber = "null";
    // var quantity = this.quantity;
    // var uoM = this.unitofmeasure;
    // var contactPerson = this.contactemail;
    // var contactPersonPhone = this.contactpersonphone;
    // var vendorid = this.vendor;
    // var company = this.company;
    // var plant = this.plant;
    // var department = this.department;
    // var costcenter = this.costcenter;
    // var category = this.category;
    // var businessPartnerText = this.bussinesspartnertext;
    // var profileid = "";
    // var invoiceDocumentPath = "";
    var invoiceamount = this.InvoiceForm.controls['Invamount'].value;
    // var igstamount = "";
    // var cgstamount = "";
    // var sgstamount = "";


    /*----------------------------Temporarily Commented ----------------------*/

    // if (this.IGST == true) {
    //   igstamount = this.InvoiceForm.controls['igstvalue'].value;
    // }
    // else {
    //   cgstamount = this.InvoiceForm.controls['cgstvalue'].value;
    //   sgstamount = this.InvoiceForm.controls['sgstvalue'].value;
    // }

    /*----------------------------Temporarily Commented End ----------------------*/


    var totalamount = this.InvoiceForm.controls['Invamount'].value;
    var description = this.InvoiceForm.controls['Description'].value;
    var status = "P";



    this.purchaseOrderListService.invoicesubmissionwithoutpo(invoiceNumber, invoicedate, invoiceamount, totalamount, description, status,useremail).subscribe(res => {
      if (res[0].message == "Success") {
        this.dialogBox.popUpOpen2('Invoice has been submitted successfully', 'success', 'invoicesubmit');
        // this.dialogBox.popUpOpen2('Invoice has been submitted successfully','success','invoicesubmit');
        // this.toastr.success("Invoice Has Been Submitted Successfully")
        console.log("Inin");
        this.InvoiceForm.reset();
        // this.invoiceconfile = null;
        this.viewAttachmentName = "";
        this.successmessage = "Invoice Has Been Submitted Successfully";
        this.success = true;
        // this.showPopup();
      }
      else {
        this.dialogBox.popUpOpen2('Error while submitting. Please try again', 'error', 'invoicesubmit');
        // this.toastr.error(res[0].message)
        // this.dialogBox.popUpOpen2('Error while submitting. Please try again','error','invoicesubmit');
        this.successmessage = "Error while submitting. Please try again";
        this.error = true;
        // this.showPopup();
      }
    })

    this.loaderservice.hide();

  }


  // totalingfunction(n, type) {
  //   console.log("calling....");

  //   var tempigstvalue = 0;
  //   var tempcgstvalue = 0;
  //   var tempsgstvalue = 0;
  //   var tempinvoiceamount = 0;
  //   if (type == "cgst") {
  //     this.specificsgst = true;
  //     this.InvoiceForm.controls['SGSTValue'].setValue(this.InvoiceForm.controls['CGSTValue'].value);
  //   }
  //   else if (type == "sgst") {
  //     this.specificcgst = true;
  //     this.InvoiceForm.controls['CGSTValue'].setValue(this.InvoiceForm.controls['SGSTValue'].value)
  //   }
  //   this.disable = false;
  //   console.log("this.InvoiceForm.controls['IGSTValue'].value" + this.InvoiceForm.controls['IGSTValue'].value);
  //   console.log("this.InvoiceForm.controls['TotalValue'].value" + this.InvoiceForm.controls['TotalValue'].value);

  //   tempigstvalue = this.parsefloatvalue(this.InvoiceForm.controls['IGSTValue'].value ? this.InvoiceForm.controls['IGSTValue'].value : 0);
  //   tempcgstvalue = this.parsefloatvalue(this.InvoiceForm.controls['CGSTValue'].value ? this.InvoiceForm.controls['CGSTValue'].value : 0);
  //   tempsgstvalue = this.parsefloatvalue(this.InvoiceForm.controls['SGSTValue'].value ? this.InvoiceForm.controls['SGSTValue'].value : 0);
  //   tempinvoiceamount = this.parsefloatvalue(this.InvoiceForm.controls['Invamount'].value ? this.InvoiceForm.controls['Invamount'].value : 0);


  //   if (this.IGST) {
  //     if (this.parsefloatvalue(tempigstvalue) > 100) {
  //       console.log("inin");
  //       this.bignumber = true;
  //       this.disable = true;
  //       return false;
  //     }
  //     else {
  //       this.bignumber = false;
  //       this.disable = false;
  //     }
  //     console.log("tempigstvalue" + tempigstvalue);
  //     console.log("tempinvoiceamount" + tempinvoiceamount);
  //     if (this.parsefloatvalue(tempigstvalue) > 100) {
  //       console.log("inin");
  //       this.bignumber = true;
  //       this.disable = true;
  //       return false;
  //     }
  //     else {
  //       this.bignumber = false;
  //       this.disable = false;
  //     }
  //     console.log("n is here" + n);
  //     this.InvoiceForm.controls['TotalValue'].setValue(
  //       this.parsefloatvalue(this.parsefloatvalue(tempinvoiceamount)
  //         + (this.parsefloatvalue(tempinvoiceamount) * (this.parsefloatvalue(tempigstvalue) / 100))));
  //   }
  //   else {

  //     if (this.parsefloatvalue(tempcgstvalue) > 100) {
  //       console.log("inin");
  //       this.bignumbercgst = true;
  //       this.bignumbersgst = false;
  //       this.disable = true;
  //       return false;
  //     }
  //     else if (this.parsefloatvalue(tempsgstvalue) > 100) {
  //       console.log("inin");
  //       this.bignumbercgst = false;
  //       this.bignumbersgst = true;
  //       this.disable = true;
  //       return false;

  //     }
  //     else {
  //       this.bignumbercgst = false;
  //       this.bignumbersgst = false;
  //       this.disable = false;
  //     }
  //     console.log("n is here" + n);
  //     if (type == "cgst") {
  //       this.InvoiceForm.controls['TotalValue'].setValue(
  //         this.parsefloatvalue(this.parsefloatvalue(tempinvoiceamount)
  //           + ((this.parsefloatvalue(tempinvoiceamount) * (this.parsefloatvalue(tempcgstvalue) / 100)))));
  //     }
  //     else if (type == "sgst") {
  //       this.InvoiceForm.controls['TotalValue'].setValue(
  //         this.parsefloatvalue(this.parsefloatvalue(tempinvoiceamount)
  //           + ((this.parsefloatvalue(tempinvoiceamount) * (this.parsefloatvalue(tempsgstvalue) / 100)))));
  //     }

  //     // this.InvoiceForm.controls['totalamount'].setValue(
  //     //   this.parsefloatvalue(this.parsefloatvalue(tempinvoiceamount)
  //     //     + ((this.parsefloatvalue(tempinvoiceamount) * (this.parsefloatvalue(tempcgstvalue) / 100)) +
  //     //       (this.parsefloatvalue(tempinvoiceamount) * (this.parsefloatvalue(tempsgstvalue) / 100)))));

  //   }
  //   console.log("n is here" + n);
  //   console.log(this.InvoiceForm.controls['Invamount'].value);

  // }

  showPopup() {
    // this.purchaseOrderListModel.PONumber = poNumber;
    $("#popup2").css("visibility", "visible");
    $("#popup2").css("opacity", "1");
  }
  parsefloatvalue(val) {
    if (val == null) {
      return 0;
    }
    else {
      return parseFloat(val);
    }
  }


  keyPressAlphanumeric(n) {
    var regex = new RegExp("^[a-zA-Z0-9-]+$");
    var str = String.fromCharCode(!n.charCode ? n.which : n.charCode);
    if (regex.test(str)) {
      return true;
    }

    n.preventDefault();
    return false;
  }

  gstvalue() {
    this.igstlist =
      [
        { id: '0.25', value: '0.25 %' },
        { id: '0.5', value: '0.5 %' },
        { id: '12', value: '12 %' },
        { id: '18', value: '18 %' },
        { id: '28', value: '28 %' }
      ]

    this.cgstandsgstlist =
      [
        { id: '0.25', value: '0.25 %' },
        { id: '0.5', value: '0.5 %' },
        { id: '12', value: '12 %' },
        { id: '18', value: '18 %' },
        { id: '28', value: '28 %' }
      ]
  }

  getFileNameWOExtention(name) {
    // return name.split(".")[0];
    var flName = name.substr(0, name.lastIndexOf(".")).replace(/_/g, "-").replace(/\./g, "-");
    return flName;
  }

  validateFileExtension(fileName) {
    let fileExtension: string = this.getExtensionOfFile(fileName);
    for (let i = 0; i < this.AttachmentValidExtension.length; i++) {
      if (this.AttachmentValidExtension[i] == fileExtension.toUpperCase())
        return true;
    }
    return false;
  }
  getExtensionOfFile(name) {
    return name.split(".")[name.split(".").length - 1];
  }
  getTimeStampFileName(fileName, extension) {
    console.log(Date.now().toString());
    return fileName + Date.now().toString() + "." + extension;
  }


  onFileSelectEvent(e, type) {
    this.errorlist = [];
    this.flag = "false";
    this.viewUploadFile = null;
    this.viewAttachmentName = "";
    console.log(e.target.files[0]);
    if (this.validateFileExtension(e.target.files[0].name)) {
      this.fileAttachmentError = "";
      this.viewUploadFile = e.target.files[0];
      if (type == "invoice") {
        this.invoiceconfile = e.target.files[0];
        this.viewAttachmentName = this.viewUploadFile.name;
        console.log("this.viewAttachmentName " + this.viewAttachmentName);
        // this.invoiceForm.controls.attachments.setValue(this.viewAttachmentName);
        this.InvoiceForm.controls['attachments'].setValue(this.viewAttachmentName);
      }
      this.actualfilename = this.viewUploadFile.name;
      console.log("this.invoiceconfile " + this.invoiceconfile);
      console.log("this.viewAttachmentName ==> " + this.viewAttachmentName);

      // console.log(this.viewAttachmentName);
      // this.neftgroup.confile.name=this.viewAttachmentName;
      var fileName = this.getFileNameWOExtention(this.viewUploadFile.name) + "_";
      fileName = this.getTimeStampFileName(fileName, this.getExtensionOfFile(this.viewUploadFile.name));
      var fileName2 = fileName;
      fileName = "bulkupload" + "_invoice_" + fileName;
      this.savedfilename = fileName;
      console.log("savedfilename ==>" + this.savedfilename);
      this.purchaseOrderListService.fileupload(this.viewUploadFile, fileName).subscribe(res => {
        console.log(JSON.stringify(res))
        res[0].data = true;
        if (res.length == 0) {
          this.toastr.error(res[0].message)
          // this.successmessage = "Data has been submitted successfully";

          //=--this.dialogBox.popUpOpen2('There was an error while uploading the file. Please try again!', 'donate', 'error2');
          return false;
        }
        else if (res[0].status == "Success" && res[0].data == true) {

          // this.getIRNNumber();


        }
        else {
          // this.toastr.error(res[0].message)
          this.dialogBox.popUpOpen2('Error while submitting. Please try again', 'error', 'invoicesubmit');
          this.successmessage = "Error while submitting. Please try again";
          this.viewAttachmentName = '';
          this.error = true;
          this.showPopup();
          //=-- this.dialogBox.popUpOpen2('Maximum file size (10 MB) exceeded.', 'donate', 'error2');
          return false;
        }

      });
      err => {
        // this.toastr.error(err)
        this.successmessage = err;
        this.error = true;
        this.showPopup();
        this.dialogBox.popUpOpen2('There was an error while uploading the file. Please try again!', 'error', 'invoicesubmit');
        // =--this.dialogBox.popUpOpen2('There was an error while uploading the file. Please try again!', 'donate', 'error2');
        return false;
      }
    }
    else {
      //Assign error message to class.
      this.fileAttachmentError = this.InvalidAttachmentFileError;
    }


    // $(".fileSelectBtn").blur();
  }





  ShowpopupMessage(ev) {
    $("#popupMessage").css("visibility", "visible");
    $("#popupMessage").css("opacity", "1");
    this.errorlist = [];
    this.flag = "false";
    this.viewAttachmentName = "";
    (<any>$("#popupComment").modal('show'));
  }
  closePopup(ev) {
    $("#popup2").css("visibility", "hidden");
    $("#popup2").css("opacity", "0");
    // location.reload();
    this.confirmationNoAction = false;
  }
  uploadfile(event: any): void {

    if (this.viewUploadFile != null && this.viewAttachmentName != "") {
      // var fileName = this.getFileNameWOExtention(this.viewUploadFile.name) + "_";
      // fileName = this.getTimeStampFileName(fileName, this.getExtensionOfFile(this.viewUploadFile.name));
      // var fileName2 = fileName;
      // fileName = "bulkupload" + "_invoice_" + fileName;
      // this.savedfilename = fileName;
      // console.log("savedfilename ==>" + this.savedfilename);
      this.purchaseOrderListService.readbulkuploadfile(this.savedfilename).subscribe(res => {
        if(res[0].flag == 'success')
        {
          this.flag = res[0].flag;
          console.log("this.flag "+this.flag);
          this.isUpload = false;
          this.viewAttachmentName = '';
          this.errorlist = res[0].errorrecords;
          this.errorcount = res[0].errorrecordscount;
          this.insertcount =res[0].correctrecordscount
          if(this.parsefloatvalue(this.errorcount) == 0)
          {
            this.dialogBox.popUpOpen2('Invoice has been uploaded successfully', 'success', 'invoicesubmit');
          }
          
          // else if(this.parsefloatvalue(this.insertcount) == 0)
          // {
          //   this.dialogBox.popUpOpen2('Error in file. Please upload proper file', 'success', 'invoicesubmit');

          // }
          else if(this.parsefloatvalue(this.errorcount) > 0 || this.parsefloatvalue(this.insertcount) == 0 )
          {
            this.dialogBox.popUpOpen2('Some invoice have been uploaded successfully', 'success', 'invoicesubmit');

          }
          // $("#popupMessage").css("visibility", "visible");
          // $("#popupMessage").css("opacity", "1");
        }
      })

      // this.purchaseOrderListService.fileupload(this.viewUploadFile, fileName).subscribe(res => {
      //   console.log(JSON.stringify(res))
      //   res[0].data = true;
      //   if (res.length == 0) {
      //     this.toastr.error(res[0].message)
      //     // this.successmessage = "Data has been submitted successfully";

      //     //=--this.dialogBox.popUpOpen2('There was an error while uploading the file. Please try again!', 'donate', 'error2');
      //     return false;
      //   }
      //   else if (res[0].status == "Success" && res[0].data == true) {

      //     // this.getIRNNumber();

      //     this.dialogBox.popUpOpen2('Invoice has been Uploaded successfully', 'success', 'invoicesubmit');
      //     this.isUpload = true;
      //     this.viewAttachmentName = '';
          
      //   }
      //   else {
      //     // this.toastr.error(res[0].message)
      //     this.dialogBox.popUpOpen2('Error while submitting. Please try again', 'error', 'invoicesubmit');
      //     this.successmessage = "Error while submitting. Please try again";
      //     this.viewAttachmentName = '';
      //     this.error = true;
      //     this.showPopup();
      //     //=-- this.dialogBox.popUpOpen2('Maximum file size (10 MB) exceeded.', 'donate', 'error2');
      //     return false;
      //   }

      // });
     

    }
  }

  close() {
    this.viewAttachmentName = '';
    this.isUpload = false;
  }

  lisitData: any =
    [
      { id: '0.25', value: '0.25 %' },
      { id: '0.5', value: '0.5 %' },
      { id: '12', value: '12 %' },
      { id: '18', value: '18 %' },
      { id: '28', value: '28 %' }
    ];

}
